/*
 * Decompiled with CFR 0.140.
 */
package lexicalAnalyzer;

public class Tag {
    public static final String SYMBL = "Symbol";
    public static final String OP = "Operator";
    public static final String LTRL = "Literal";
    public static final String INT = "IntNO";
    public static final String ID = "Identifier";
    public static final String IDSP = "IdentifierSpecial";
    public static final String KWRD = "Keyword";
    public static final String PLUS = "+";
    public static final String MINUS = "-";
    public static final String MULTIPLY = "*";
    public static final String DEVIDE = "/";
    public static final String MODULUS = "%";
    public static final String ASGN = "=";
    public static final String EQ = "==";
    public static final String LE = "<=";
    public static final String GE = ">=";
    public static final String GT = ">";
    public static final String LT = "<";
    public static final String INTEGER = "int";
    public static final String FLOAT = "float";
    public static final String CHAR = "char";
    public static final String LOOP = "for";
    public static final String PCOND = "if";
    public static final String SCOND = "else if";
    public static final String FCOND = "else";
    public static final String TRUE = "true";
    public static final String FALSE = "false";
    public static final String SHOW = "System.out.print";
    public static final String SHOWLINE = "System.out.println";
    public static final String REPLY = "return";
    public static final String ENDURE = "continue";
    public static final String INTERRUPT = "break";
}
