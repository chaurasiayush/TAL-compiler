/*
 * Decompiled with CFR 0.140.
 */
package lexicalAnalyzer;

import lexicalAnalyzer.Token;

public class FloatNO
extends Token {
    public FloatNO(Float f) {
        super("float", f.toString());
    }
}
