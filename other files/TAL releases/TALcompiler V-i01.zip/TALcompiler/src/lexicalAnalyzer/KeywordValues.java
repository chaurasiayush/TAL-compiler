/*
 * Decompiled with CFR 0.140.
 */
package lexicalAnalyzer;

public class KeywordValues {
    public static final String INTEGER = "int";
    public static final String FLOAT = "float";
    public static final String CHAR = "char";
    public static final String LOOP = "for";
    public static final String PCOND = "if";
    public static final String SCOND = "else if";
    public static final String FCOND = "else";
    public static final String TRUE = "true";
    public static final String FALSE = "false";
    public static final String SHOW = "System.out.print";
    public static final String SHOWLINE = "System.out.println";
    public static final String REPLY = "return";
    public static final String ENDURE = "continue";
    public static final String INTERRUPT = "break";
}
