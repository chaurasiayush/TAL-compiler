/*
 * Decompiled with CFR 0.140.
 */
package lexicalAnalyzer;

import lexicalAnalyzer.Token;

public class Identifier
extends Token {
    String v;

    public Identifier() {
    }

    public Identifier(String value) {
        super("Identifier", value);
    }
}
