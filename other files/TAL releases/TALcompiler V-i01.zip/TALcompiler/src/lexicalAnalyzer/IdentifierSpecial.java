/*
 * Decompiled with CFR 0.140.
 */
package lexicalAnalyzer;

import lexicalAnalyzer.Token;

public class IdentifierSpecial
extends Token {
    String v;
    public static final IdentifierSpecial show = new IdentifierSpecial("System.out.print");
    public static final IdentifierSpecial showLine = new IdentifierSpecial("System.out.println");

    public IdentifierSpecial() {
    }

    public IdentifierSpecial(String value) {
        super("IdentifierSpecial", value);
    }
}
