/*
 * Decompiled with CFR 0.140.
 */
package lexicalAnalyzer;

import lexicalAnalyzer.Token;

public class Keyword
extends Token {
    public static final Keyword reply = new Keyword("return");
    public static final Keyword intg = new Keyword("IntNO");
    public static final Keyword floatg = new Keyword("float");

    Keyword(String value) {
        super("Keyword", value);
    }
}
