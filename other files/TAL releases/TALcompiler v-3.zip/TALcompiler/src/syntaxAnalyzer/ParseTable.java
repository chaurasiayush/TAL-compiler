/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer;

import java.util.HashMap;
import lexicalAnalyzer.Token;

/**
 *
 * @author ayush
 */
public class ParseTable {
    HashMap<String [],Object> PTable = new HashMap();
    
    public void insert(String key[], Object ob){
        if(key.length == 2){
            PTable.put(key, ob);
        }
       
    }
    

}
