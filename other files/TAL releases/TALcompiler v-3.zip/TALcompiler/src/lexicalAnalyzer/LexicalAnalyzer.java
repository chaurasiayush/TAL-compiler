/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lexicalAnalyzer;

import java.io.IOException;
import java.util.HashMap;
import errorHandler.Error;
import symbolTable.*;
/**
 *
 * @author ayush
 */
public class LexicalAnalyzer {
 
    HashMap<String, Keyword> keyw = new HashMap();
    HashMap<String, IdentifierSpecial> idsp = new HashMap();
    char peek = ' ';
    int line = 1;

//-----------------------------------------------------------------------------------------------------------------------    
   
    public LexicalAnalyzer(){
        reserveKW();
        reserveIDSP();
    }
    
    private void reserveKW(){
        keyw.put("intg",Keyword.intg );
        keyw.put("reply",Keyword.reply);
        keyw.put("floatg",Keyword.floatg);
        keyw.put("loop",Keyword.loop);
        keyw.put("pcond",Keyword.pcond);
        keyw.put("scond",Keyword.scond);
        keyw.put("fcond",Keyword.fcond);
        keyw.put("ctrue",Keyword.ctrue);
        keyw.put("cfalse",Keyword.cfalse);
        keyw.put("endure",Keyword.endure);
        keyw.put("interrupt",Keyword.interrupt);
    }
    
    private void reserveIDSP() {
        this.idsp.put("show", IdentifierSpecial.show);
        this.idsp.put("showLine", IdentifierSpecial.showLine);
    }
//-----------------------------------------------------------------------------------------------------------------------
    
    private void read(){
        try{    
            peek = (char)System.in.read();
        }catch(IOException e){
            System.out.println("Inavalid Char!!");
        }
    }
    
    private boolean readChar(char a){
        read();
        if(peek == a)
            return true;
        peek = ' ';
        return false;
    }
    
//-----------------------------------------------------------------------------------------------------------------------
    
    public Token getToken(){
        
        
        for (;; read()) {
            if (peek == ' ' || peek == '\t') {
                //continue;
            } else if (peek == '\n') {
                line = line + 1;
            } else {
                break;
            }
        }
        
        //----------------------------------------------------------------------------------------------------------------

        switch(peek){
            
            case '=':
                
                if(readChar('=')){
                   System.out.println("\"==\"\t\t"+"<"+Tag.OP+">");
                   return Operator.EQUAL;
                }
                read();
                System.out.println("\"=\"\t\t"+"<"+Tag.OP+">");    
                return Operator.ASGN;
                
            case '+':
                read();
                System.out.println("\"+\"\t\t"+"<"+Tag.OP+">");
                return Operator.PLUS;
                
            case '(':
                read();
                System.out.println("\"(\"\t\t"+"<"+Tag.SYMBL+">");
                return Symbol.OPENBR;
                
            case ')':
                read();
                System.out.println("\")\"\t\t"+"<"+Tag.SYMBL+">");
                return Symbol.CLOSEBR;
                
            case '{':
                read();
                System.out.println("\"{\"\t\t"+"<"+Tag.SYMBL+">");
                return Symbol.OPENCR;
                
            case '}':
                read();
                System.out.println("\"}\"\t\t"+"<"+Tag.SYMBL+">");
                return Symbol.CLOSECR;
                
            case ';':
                read();
                System.out.println("\":\"\t\t"+"<"+Tag.SYMBL+">");
                return Symbol.SEMICLN;
                
        }// switch ends here
        
        //----------------------------------------------------------------------------------------------------------------
        
        if(Character.isLetter(peek)){                                           // creates token for valid IDETIFIER
                                                                                
            StringBuilder sb = new StringBuilder();

            do{
                sb.append(peek);
                read();
            }while(Character.isLetterOrDigit(peek));
        
            String s = sb.toString();
            Keyword w = keyw.get(s);
            if(w != null){
                System.out.println("\""+s+"\"\t\t"+"<"+Tag.KWRD+">");
                return w;
            }
            IdentifierSpecial sid = this.idsp.get(s);
            if (sid != null) {
                System.out.println("\"" + s + "\"\t\t<" + "IdentifierSpecial" + ">");
                if (!SymbolTable.stable.containsKey(s)) {
                    STData sd = new STData(sid, this.line);
                    SymbolTable.stable.put(s, sd);
                    return sid;
                }
            } else {
                System.out.println("\"" + s + "\"\t\t<" + "Identifier" + ">");
                Identifier id = new Identifier(s);
                if (!SymbolTable.stable.containsKey(s)) {
                    STData sd = new STData(id, this.line);
                    SymbolTable.stable.put(s, sd);
                    return id;
                }
            }
        }
        
        
        //----------------------------------------------------------------------------------------------------------------
        
        
        if(Character.isDigit(peek)){                                            //creates token for INTEGER numbers as well as INVALID IDENTIFIERS (eg: 07id)
            
            StringBuilder sb = new StringBuilder();
            int vlue = 0;                
            do{
                sb.append(peek);
                vlue = vlue*10 + Character.digit(peek, 10);        
                read();
            }while((peek != ' '|| peek != ';' || peek == '\t')&& Character.isDigit(peek));
            
            if(peek == '.'){
                float x = vlue, d = 10;
                for (;;) {
                    read();
                    if (!Character.isDigit(peek)) {
                        break;
                    }
                    x = x + Character.digit(peek, 10) / d;
                    d = d * 10;
                }
                System.out.println("\""+x+"\"\t\t"+"<"+Tag.FLOAT+">");
                return new FloatNO(x);
            }
            
            
            if(peek == ' '|| peek == ';' || peek == '\t'){
                
                System.out.println("\""+vlue+"\"\t\t"+"<"+Tag.INT+">");
                return new IntNO(vlue);
 
            }
            
            else{                                                               //creates INVALID IDENTIFIERS
               
                do{
                    sb.append(peek);
                    read();
                }while(Character.isLetterOrDigit(peek));
                String sbstr = sb.toString();
                Error.lexicalError(sbstr,line);
                return new Identifier(sbstr);
            }
        }
        
        if(peek == '"'){
            StringBuilder sb = new StringBuilder();
            while(true){
                read();
                if(peek == '"'){
                    read();
                    break;
                }
                sb.append(peek);
            }
            String literal = sb.toString();
            System.out.println("\""+literal+"\"\t\t"+"<"+Tag.LTRL+">");
            return new Literal(literal);
        }
        
        Token t = new Token();
        peek = ' ';
        return t;
    }
}

