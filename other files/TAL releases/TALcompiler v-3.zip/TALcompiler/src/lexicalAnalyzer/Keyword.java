/*
 * author Ayush Chaurasia (CSJMA16001390016)
 */
package lexicalAnalyzer;

import lexicalAnalyzer.Token;

public class Keyword
extends Token {
    
    public static final Keyword reply = new Keyword(KeywordValues.REPLY);
    public static final Keyword intg = new Keyword(KeywordValues.INTG);
    public static final Keyword floatg = new Keyword(KeywordValues.FLOATG);
    public static final Keyword loop = new Keyword(KeywordValues.LOOP);
    public static final Keyword pcond = new Keyword(KeywordValues.PCOND);
    public static final Keyword scond = new Keyword(KeywordValues.SCOND);
    public static final Keyword fcond = new Keyword(KeywordValues.FCOND);
    public static final Keyword ctrue = new Keyword(KeywordValues.CTRUE);
    public static final Keyword cfalse = new Keyword(KeywordValues.CFALSE);
    public static final Keyword endure = new Keyword(KeywordValues.ENDURE);
    public static final Keyword interrupt = new Keyword(KeywordValues.INTERRUPT);

    Keyword(String value) {
        super("Keyword", value);
    }
}
