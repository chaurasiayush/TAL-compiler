
import syntaxAnalyzer.grammer.NonTerminal;
import java.lang.ClassLoader;
/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */

/**
 *
 * @author ayush
 */
public class Test {
    public static void main(String sgs[]){
        
       NonTerminal e = new NonTerminal("E");
       Object d = e;
       if(d.getClass()==e.getClass())
       
       
       System.out.println("hvhjvjhv");
    }
}
