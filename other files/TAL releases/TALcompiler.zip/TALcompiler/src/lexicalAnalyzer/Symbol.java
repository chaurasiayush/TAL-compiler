/*
 * author Ayush Chaurasia (CSJMA16001390016)
 */
package lexicalAnalyzer;

import lexicalAnalyzer.Token;

public class Symbol
extends Token {
    char lexeme;
    public static Symbol OPENBR = new Symbol("(");
    public static Symbol CLOSEBR = new Symbol(")");
    public static Symbol OPENCR = new Symbol("{");
    public static Symbol CLOSECR = new Symbol("}");
    public static Symbol SEMICLN = new Symbol(";");

    Symbol(String value) {
        super("Symbol", value);
        this.lexeme = value.charAt(0);
    }
}
