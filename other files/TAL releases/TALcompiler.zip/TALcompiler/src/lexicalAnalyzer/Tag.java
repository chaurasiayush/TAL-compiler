/*
 * author Ayush Chaurasia (CSJMA16001390016)
 */
package lexicalAnalyzer;

public class Tag {
    public static final String SYMBL = "Symbol";
    public static final String OP = "Operator";
    public static final String LTRL = "Literal";
    public static final String INT = "IntNO";
    public static final String FLOAT = "FloatNO";
    public static final String ID = "Identifier";
    public static final String IDSP = "IdentifierSpecial";
    public static final String KWRD = "Keyword";
    
    public static final String PLUS = "+";
    public static final String MINUS = "-";
    public static final String MULTIPLY = "*";
    public static final String DEVIDE = "/";
    public static final String MODULUS = "%";
    public static final String ASGN = "=";
    public static final String EQ = "==";
    public static final String LE = "<=";
    public static final String GE = ">=";
    public static final String GT = ">";
    public static final String LT = "<";
    
    

}
