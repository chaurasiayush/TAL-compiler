/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer.grammer;
import lexicalAnalyzer.Token;

/**
 *
 * @author ayush
 */
public class NonTerminal extends Token{

    
    public NonTerminal(String name){
        super("NonTerminal",name);
    }
    
    
}
