/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer.grammer;

import java.util.Stack;
import lexicalAnalyzer.Token;

/**
 *
 * @author ayush
 */
public class Production {
    
    Stack<Token> prd = new Stack();
    
    
}
