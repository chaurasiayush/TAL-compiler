

/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */

/**
 *
 * @author ayush
 */
public class Test {
    public static void main(String[] args){
        
//      int a=9,b=7,d;
//       
//      d = 5*a-7*b-4*b;
       
       
       System.out.println("t2.r");
    }
}

class t2{
    public static int r;
    static void print(){
        r = 3;
    }
}