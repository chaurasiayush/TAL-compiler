/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer;

import java.util.HashMap;
import java.util.HashSet;
import syntaxAnalyzer.parseTable.NonTerminal;

/**
 *
 * @author ayush
 */
public class Grammar {
    
    public HashMap<Integer, Rule> grammar = new HashMap();
    public HashSet<String> nonTerminal = new HashSet();
    public static Grammar G1;
    

    static{
       
        G1 = new Grammar();
        G1.grammar.put(0,Rule.R0);
        G1.grammar.put(1,Rule.R1);
        G1.grammar.put(2,Rule.R2);
        G1.grammar.put(3,Rule.R3);
        G1.grammar.put(4,Rule.R4);
        G1.grammar.put(5,Rule.R5);
        
        
        G1.nonTerminal.add(NonTerminal.START);
        G1.nonTerminal.add(NonTerminal.S);
        G1.nonTerminal.add(NonTerminal.B);
        G1.nonTerminal.add(NonTerminal.G);
        G1.nonTerminal.add(NonTerminal.Y);
       // G1.nonTerminal.add(NonTerminal);
            
        
    }
        
        
       
}
    


