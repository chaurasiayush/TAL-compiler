/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer;

import syntaxAnalyzer.parseTable.NonTerminal;

/**
 *
 * @author ayush
 */
class Rule{
    
    public int size;
    public String nonterminal;
    
    public static Rule R0, R1, R2, R3, R4, R5, R6;
    
    public Rule(int sz, String nt){
        
        this.size = sz;
        this.nonterminal = nt;
        
    }
    
    static{
        R0 = new Rule(1,NonTerminal.START);
        R1 = new Rule(4,NonTerminal.S);
        R2 = new Rule(3,NonTerminal.B);
        R3 = new Rule(2,NonTerminal.Y);
        R4 = new Rule(3,NonTerminal.G);
        R5 = new Rule(0,NonTerminal.Y);
//        R1 = new Rule(4,NonTerminal);
//        R1 = new Rule(4,NonTerminal);

    }
}