/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer.parseTable;

import java.util.HashMap;
import syntaxAnalyzer.Infopkg;

/**
 *
 * @author ayush
 */
public class GotoTable {
    
    HashMap<String,Integer> gototable = new HashMap();
    
    public static final GotoTable GT1 = new GotoTable();
    
    public int getGoto(String key){
        
        int gotostate = gototable.get(key);
        return gotostate;
        
    }
    static{
        
        GT1.gototable.put(GotoKey.TF0S, 1);
        GT1.gototable.put(GotoKey.TF4B, 5);
        GT1.gototable.put(GotoKey.TF6G, 7);
        GT1.gototable.put(GotoKey.TF6Y, 8);
        GT1.gototable.put(GotoKey.TF7G, 7);
        GT1.gototable.put(GotoKey.TF7Y, 10);
//        GT1.gototable.put(GotoKey, 1);
//        GT1.gototable.put(GotoKey, 1);
//        GT1.gototable.put(GotoKey, 1);
    }
    
}

class GotoKey{

    int state;
    String nonterminal;
    
    public static final String TF0S = String.valueOf(0).concat("."+NonTerminal.S),
                                TF4B = String.valueOf(4).concat("."+NonTerminal.B),
                                TF6G = String.valueOf(6).concat("."+NonTerminal.G),
                                TF6Y = String.valueOf(6).concat("."+NonTerminal.Y),
                                TF7G = String.valueOf(7).concat("."+NonTerminal.G),
                                TF7Y = String.valueOf(7).concat("."+NonTerminal.Y);
    //
    public GotoKey(int state, String nonterminal){
        
        this.state = state;
        this.nonterminal = nonterminal;
        
    }
}