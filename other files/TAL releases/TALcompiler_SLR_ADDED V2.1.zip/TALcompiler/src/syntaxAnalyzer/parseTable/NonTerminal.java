/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer.parseTable;

/**
 *
 * @author ayush
 */
public class NonTerminal {
    
    public static String START = "START";
    public static String S = "S";
    public static String B = "B";
    public static String Y = "Y";
    public static String G = "G";
    
}
