/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer.parseTable;

//import java.util.;
import java.util.Hashtable;
import lexicalAnalyzer.Tag;
import syntaxAnalyzer.Infopkg;
import talcompiler.TALcompiler;

/**
 *
 * @author ayush
 */
public class ActionTable {
    
    Hashtable<String,Block> atable = new Hashtable();
    
    public static final ActionTable AT1 = new ActionTable();
    
    public Infopkg getAction(String k){
        
        
        Block b = atable.get(k);
        
        
        //TALcompiler.logWriter.println("KEY RECEIVED AT ACTION TABLE : "+k+"\nCORRESPONDING VALUE:  intinfo - "+b.intInfo+"\tactionType - "+b.actiontype);
        Infopkg retInfo = null;
        
        if(b.actiontype == ActionType.SHIFT)
             retInfo = new Infopkg(b.intInfo,b.actiontype);
        
        else if(b.actiontype == ActionType.REDUCE)
            retInfo = new Infopkg(b.intInfo,b.actiontype,0);
        
        else if(b.actiontype == ActionType.ACCEPT){
            retInfo = new Infopkg(999, ActionType.ACCEPT);
        }
        
        return retInfo;
        
    }
   
    static{
    
        
        AT1.atable.put(Key.T1KEY0e, Block.TF0e);
        AT1.atable.put(Key.T1KEY1$, Block.TF1$);
        AT1.atable.put(Key.T1KEY10CLCR, Block.TF10CLCR);
        AT1.atable.put(Key.T1KEY11$, Block.TF11$);
        AT1.atable.put(Key.T1KEY12SCLN, Block.TF12SCLN);
        AT1.atable.put(Key.T1KEY13CLCR, Block.TF13CLCR);
        AT1.atable.put(Key.T1KEY13d, Block.TF13d);
        AT1.atable.put(Key.T1KEY2OPBR, Block.TF2OPBR);
        AT1.atable.put(Key.T1KEY3CLBR, Block.TF3CLBR);
        AT1.atable.put(Key.T1KEY4OPCR, Block.TF4OPCR);
        AT1.atable.put(Key.T1KEY5$, Block.TF5$);
        AT1.atable.put(Key.T1KEY6CLCR, Block.TF6CLCR);
        AT1.atable.put(Key.T1KEY6d, Block.TF6d);
        AT1.atable.put(Key.T1KEY7CLCR, Block.TF7CLCR);
        AT1.atable.put(Key.T1KEY7d, Block.TF7d);
        AT1.atable.put(Key.T1KEY8CLCR, Block.TF8CLCR);
        AT1.atable.put(Key.T1KEY9i, Block.TF9i);
        
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
//        AT1.atable.put(Key, Block);
    }
}

class Key{
    
    
    public static String T1KEY0e = String.valueOf(0).concat("."+Tag.IDSP_EXE), 
                      T1KEY1$ = String.valueOf(1).concat("."+Tag.END), 
                      T1KEY2OPBR = String.valueOf(2).concat("."+Tag.SYMBL_OPBR), 
                      T1KEY3CLBR = String.valueOf(3).concat("."+Tag.SYMBL_CLBR),
                      T1KEY4OPCR = String.valueOf(4).concat("."+Tag.SYMBL_OPCR), 
                      T1KEY5$ = String.valueOf(5).concat("."+Tag.END), 
                      T1KEY6d = String.valueOf(6).concat("."+Tag.KW_DATATYPE),  
                      T1KEY6CLCR = String.valueOf(6).concat("."+Tag.SYMBL_CLCR),
                      T1KEY7d = String.valueOf(7).concat("."+Tag.KW_DATATYPE),  
                      T1KEY7CLCR = String.valueOf(7).concat("."+Tag.SYMBL_CLCR), 
                      T1KEY8CLCR = String.valueOf(8).concat("."+Tag.SYMBL_CLCR),  
                      T1KEY9i = String.valueOf(9).concat("."+Tag.ID),
                      T1KEY10CLCR = String.valueOf(10).concat("."+Tag.SYMBL_CLCR),  
                      T1KEY11$ = String.valueOf(11).concat("."+Tag.END),  
                      T1KEY12SCLN = String.valueOf(12).concat("."+Tag.SYMBL_SEMICOLON),  
                      T1KEY13d = String.valueOf(13).concat("."+Tag.KW_DATATYPE),
                      T1KEY13CLCR  = String.valueOf(13).concat("."+Tag.SYMBL_CLCR);
    
    
}

class Block{
    
    int intInfo;
    String actiontype;
    public static final Block TF0e = new Block(2,ActionType.SHIFT), TF1$ = new Block(0,ActionType.ACCEPT), TF2OPBR = new Block(3,ActionType.SHIFT),TF3CLBR = new Block(4,ActionType.SHIFT),  TF4OPCR = new Block(6,ActionType.SHIFT),
             TF5$ = new Block(1,ActionType.REDUCE), TF6d = new Block(9,ActionType.SHIFT), TF6CLCR = new Block(5,ActionType.REDUCE), TF7d = new Block(9,ActionType.SHIFT), TF7CLCR = new Block(5,ActionType.REDUCE),
             TF8CLCR = new Block(11,ActionType.SHIFT), TF9i = new Block(12,ActionType.SHIFT), TF10CLCR = new Block(3,ActionType.REDUCE), TF11$ = new Block(2,ActionType.REDUCE),
             TF12SCLN = new Block(13,ActionType.SHIFT), TF13d = new Block(4,ActionType.REDUCE), TF13CLCR = new Block(4,ActionType.REDUCE);

    public Block(int intInfo, String actiontype){
        
        this.intInfo = intInfo;
        this.actiontype = actiontype;
        
    }
}

class ActionTableDriver{

    public static void main(String Arg[]){

        ActionTable a = ActionTable.AT1;
        
        //Block b = a.atable.get("1.$");
        Infopkg i = a.getAction("0.".concat(Tag.IDSP_EXE));
        System.out.println(i.actionType+" "+i.state+" "+i.nterminal+" "+i.terminal);
}


}