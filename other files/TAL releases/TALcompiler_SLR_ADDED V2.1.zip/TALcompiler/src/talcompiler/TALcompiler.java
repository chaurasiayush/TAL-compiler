/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package talcompiler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import syntaxAnalyzer.Grammar;
import syntaxAnalyzer.SLRparser;
import syntaxAnalyzer.parseTable.ActionTable;
import syntaxAnalyzer.parseTable.GotoTable;

/**
 *
 * @author ayush
 */
public class TALcompiler {

    public static PrintStream logWriter;
    public static PrintStream TAGTRACER;
    
    static {
        try {
            logWriter  = new PrintStream("parselog.log");
            TAGTRACER  = new PrintStream("tagtrace.log");
            
        }catch (IOException e){
            System.out.println("log Files coulden't be created!");
        }
    }
    
    public static void main(String args[]) throws Exception{
        
        File f = new File("inp2.tal");
        
        FileInputStream fs = new FileInputStream(f); 
        
        System.setIn(fs); 
        //LexicalAnalyzer la = new LexicalAnalyzer(); 
       
        SLRparser parser = new SLRparser(ActionTable.AT1, GotoTable.GT1, Grammar.G1);
        parser.parse();
       
    }

}
    

