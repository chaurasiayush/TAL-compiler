/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errorHandler;

/**
 *
 * @author ayush
 */
public class Error {
    
    public static int i;
    public static void SyntaxError(int l){
        System.out.println("Syntax Error at Line : \""+l+"\"");
    }
    
    public static void lexicalError(String id,int line){
        System.out.println("Lexical error: Bad Identifier \""+id+"\" at line : "+line);
    }
}
