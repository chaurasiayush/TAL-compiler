/*
 * author Ayush Chaurasia (CSJMA16001390016)
 */
package lexicalAnalyzer;

public class Tag {
    public static final String SYMBL_OPBR = "SYMBL_OpenBr";
    public static final String SYMBL_CLBR = "SYMBL_CloseBr";
    public static final String SYMBL_OPCR = "SYMBL_OpenCurly";
    public static final String SYMBL_CLCR = "SYMBL_CloseCurly";
    public static final String SYMBL_SEMICOLON = "SYMBL_Semicolon";
    public static final String SYMBL_QUOTE = "SYMBL_Quote";
    
    public static final String OP_EQ = "OPERATOR_EQUAL";
    public static final String OP_PLUS = "OPERATOR_PLUS";
    public static final String OP_MINUS = "OPERATOR_MINUS";
    public static final String OP_DEVIDE = "OPERATOR_DEVIDE";
    public static final String OP_MULTIPLY = "OPERATOR_MULTIPLY";
    public static final String OP_GE = "OPERATOR_GE";
    public static final String OP_ASGN = "OPERATOR_ASGN";
    
    public static final String LTRL = "Literal";
    public static final String ID = "Identifier";
    //public static final String IDSP = "IdentifierSpecial";
    public static final String END = "$";
    
    public static final String PLUS = "+";
    public static final String MINUS = "-";
    public static final String MULTIPLY = "*";
    public static final String DEVIDE = "/";
    public static final String MODULUS = "%";
    public static final String ASGN = "=";
    public static final String EQ = "==";
    public static final String LE = "<=";
    public static final String GE = ">=";
    public static final String GT = ">";
    public static final String LT = "<";
    
    //keywords
    
    public static final String IDSP_EXE = "IDSP_exe";
    public static final String IDSP_SHOW = "IDSP_show";
    public static final String IDSP_SHOWINE = "IDSP_showLine";
    public static final String KW_DATATYPE = "KW_datatype";
    public static final String FLOAT_NO = "FloatNO";
    public static final String INT_NO = "IntNO";
    public static final String LOOP = "KW_loop";
    public static final String PCOND = "KW_pcond";
    public static final String SCOND = "KW_scond";
    public static final String FCOND = "KW_fcond";
    public static final String CTRUE = "KW_tf";
    public static final String CFALSE = "KW_tf";
    public static final String ENDURE = "KW_endure";
    public static final String INTERRUPT = "KW_interrupt";
    public static final String REPLY = "KW_reply";
    
    
    

}
