/*

--------------------------------
 TALcompiler project           
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh          
  * Anish Shrivastav                
  * Ayush Chaurasia    
--------------------------------

 */
package syntaxAnalyzer.parseTable;

/**
 *
 * @author ayush
 */
public class NonTerminal {
    
    public static String START = "START";
    public static String S = "S";
    public static String B = "B";
    public static String Y = "Y";
    public static String G = "G";
    public static String A = "A";
    public static String D = "D";
    public static String E = "E";
    public static String F = "F";
    public static String P = "P";
    public static String R = "R";
    //public static String S = "G";
    public static String T = "T";
    //public static String Y = "G";
    public static String Z = "Z";
   
}
