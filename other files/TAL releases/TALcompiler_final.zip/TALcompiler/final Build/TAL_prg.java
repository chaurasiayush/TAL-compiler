/* this file is generated through TALcompiler 


--------------------------------
           TALcompiler          
--------------------------------
 Developed by-   
  * Abhishek Kumar Singh        
  * Anish Shrivastav            
  * Ayush Chaurasia    
--------------------------------
 
*/

import java.lang.*;
import java.util.*;
import java.io.*;


public class TAL_prg{

}
